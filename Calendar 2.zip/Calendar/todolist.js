const modal = document.getElementById("todoModal");
const btnClose = document.querySelector(".close");
const btnAddTodo = document.getElementById("addTodo");
const inputTodo = document.getElementById("todoInput");
const todoList = document.getElementById("todoList");

// 날짜 클릭 이벤트 리스너 추가
document.querySelector(".days").addEventListener("click", function(event) {
  if (event.target.tagName === "LI") {
    modal.style.display = "block";
  }
});

// 모달 닫기
btnClose.onclick = function() {
  modal.style.display = "none";
}

// 윈도우에서 모달 바깥 영역 클릭 시 모달 닫기
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}

// 투두리스트 추가
btnAddTodo.onclick = function() {
  const todoText = inputTodo.value;
  if (todoText) {
    const li = document.createElement("li");

    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.addEventListener("click", function() {
      li.classList.toggle("completed");
    });

    const span = document.createElement("span");
    span.textContent = todoText;

    const deleteButton = document.createElement("button");
    deleteButton.textContent = "삭제";
    deleteButton.addEventListener("click", function() {
      li.remove();
    });

    li.appendChild(checkbox);
    li.appendChild(span);
    li.appendChild(deleteButton);

    todoList.appendChild(li);
    inputTodo.value = ""; // 입력 필드 초기화
  }
}

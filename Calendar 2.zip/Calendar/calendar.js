const daysTag = document.querySelector(".days"),
currentDate = document.querySelector(".current-date"),
prevNextIcon = document.querySelectorAll(".icons span");

// 새로운 날짜, 현재 연도 및 월을 가져옵니다.
let date = new Date(),
currYear = date.getFullYear(),
currMonth = date.getMonth();

// 모든 월의 전체 이름을 배열에 저장합니다.
const months = ["January", "February", "March", "April", "May", "June", "July",
              "August", "September", "October", "November", "December"];

const renderCalendar = () => {
    // 월의 첫 번째 날을 가져옵니다.
    let firstDayofMonth = new Date(currYear, currMonth, 1).getDay(),
    // 월의 마지막 날짜를 가져옵니다.
    lastDateofMonth = new Date(currYear, currMonth + 1, 0).getDate(),
    // 월의 마지막 날을 가져옵니다.
    lastDayofMonth = new Date(currYear, currMonth, lastDateofMonth).getDay(),
    // 이전 월의 마지막 날짜를 가져옵니다.
    lastDateofLastMonth = new Date(currYear, currMonth, 0).getDate();
    let liTag = "";

    // 이전 달의 마지막 일들의 li를 생성합니다.
    for (let i = firstDayofMonth; i > 0; i--) {
        liTag += `<li class="inactive">${lastDateofLastMonth - i + 1}</li>`;
    }

    // 현재 월의 모든 일의 li를 생성합니다.
    for (let i = 1; i <= lastDateofMonth; i++) {
        // 현재 일, 월, 연도가 일치하면 li에 active 클래스를 추가합니다.
        let isToday = i === date.getDate() && currMonth === new Date().getMonth() 
                     && currYear === new Date().getFullYear() ? "active" : "";
        liTag += `<li class="${isToday}">${i}</li>`;
    }

    // 다음 달의 첫 일들의 li를 생성합니다.
    for (let i = lastDayofMonth; i < 6; i++) {
        liTag += `<li class="inactive">${i - lastDayofMonth + 1}</li>`
    }
    // 현재 월과 연도를 currentDate 텍스트로 전달합니다.
    currentDate.innerText = `${months[currMonth]}`;
    daysTag.innerHTML = liTag;
}
renderCalendar();

prevNextIcon.forEach(icon => { // 이전 및 다음 아이콘을 가져옵니다.
    icon.addEventListener("click", () => { // 두 아이콘 모두에 클릭 이벤트를 추가합니다.
        // 클릭된 아이콘이 이전 아이콘이면 현재 월을 1 감소시키고, 그렇지 않으면 1 증가시킵니다.
        currMonth = icon.id === "prev" ? currMonth - 1 : currMonth + 1;

        if(currMonth < 0 || currMonth > 11) { // 현재 월이 0보다 작거나 11보다 큰 경우
            // 현재 연도 및 월의 새로운 날짜를 생성하고 date 값으로 전달합니다.
            currYear = date.getFullYear(); // 새 날짜의 연도로 현재 연도를 업데이트합니다.
            currMonth = date.getMonth(); // 새 날짜의 월로 현재 월을 업데이트합니다.
        } else {
            date = new Date(); // 현재 날짜를 date 값으로 전달합니다.
        }
        renderCalendar(); // renderCalendar 함수를 호출합니다.
    });
});
